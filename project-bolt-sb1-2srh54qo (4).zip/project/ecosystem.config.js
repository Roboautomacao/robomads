module.exports = {
  apps: [{
    name: 'google-ads-automation',
    script: 'npm',
    args: 'run preview',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
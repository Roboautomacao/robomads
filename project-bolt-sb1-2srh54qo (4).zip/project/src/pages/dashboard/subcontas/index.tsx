import { useEffect, useState } from 'react';
import { Card, Title, Text, Button, Table, TableHead, TableRow, TableHeaderCell, TableBody, TableCell } from '@tremor/react';
import { useRouter } from 'next/router';
import { supabase } from '@/lib/supabase';

interface SubAccount {
  id: string;
  customerId: string;
  name: string;
  status: string;
  createdAt: string;
}

export default function Subcontas() {
  const router = useRouter();
  const [subcontas, setSubcontas] = useState<SubAccount[]>([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        router.push('/');
      } else {
        setUser(session.user);
        carregarSubcontas(session.user.id);
      }
    });
  }, [router]);

  async function carregarSubcontas(userId: string) {
    const { data, error } = await supabase
      .from('SubAccount')
      .select('*')
      .eq('userId', userId);

    if (error) {
      console.error('Erro ao carregar subcontas:', error);
      return;
    }

    setSubcontas(data || []);
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex justify-between items-center mb-8">
          <div>
            <Title>Subcontas</Title>
            <Text>Gerencie suas subcontas do Google Ads</Text>
          </div>
          <Button onClick={() => router.push('/dashboard/subcontas/nova')}>
            Nova Subconta
          </Button>
        </div>

        <Card>
          <Table>
            <TableHead>
              <TableRow>
                <TableHeaderCell>Nome</TableHeaderCell>
                <TableHeaderCell>ID do Cliente</TableHeaderCell>
                <TableHeaderCell>Status</TableHeaderCell>
                <TableHeaderCell>Data de Criação</TableHeaderCell>
                <TableHeaderCell>Ações</TableHeaderCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {subcontas.map((subconta) => (
                <TableRow key={subconta.id}>
                  <TableCell>{subconta.name}</TableCell>
                  <TableCell>{subconta.customerId}</TableCell>
                  <TableCell>{subconta.status}</TableCell>
                  <TableCell>
                    {new Date(subconta.createdAt).toLocaleDateString('pt-BR')}
                  </TableCell>
                  <TableCell>
                    <Button
                      size="xs"
                      onClick={() => router.push(`/dashboard/subcontas/${subconta.id}`)}
                    >
                      Detalhes
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>
    </div>
  );
}